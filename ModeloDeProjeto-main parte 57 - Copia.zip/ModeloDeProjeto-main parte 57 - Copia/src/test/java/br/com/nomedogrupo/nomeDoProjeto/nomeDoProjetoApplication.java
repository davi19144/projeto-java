package br.com.nomedogrupo.nomeDoProjeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class nomeDoProjetoApplication {

	@Test
	void contextLoads() {
	}

}
