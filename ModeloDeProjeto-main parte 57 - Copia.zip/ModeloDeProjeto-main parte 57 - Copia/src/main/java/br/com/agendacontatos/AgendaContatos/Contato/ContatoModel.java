package br.com.agendacontatos.AgendaContatos.Contato;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;


@Data
@Entity(name = "tb_contato")
public class ContatoModel {
	@Id
    @GeneratedValue(generator = "UUID")
    private String Telefone_contato;
    private String Nome_contato;
    private String Sobrenome_contato;
    private String Email_contato;
    private String DataDeNascimento_contato;
    private String Senha_contato;
    private String Tag;
    
    @Column(unique = true)
    private String idUsuario;

    @CreationTimestamp
    private LocalDateTime createdAt;

}

