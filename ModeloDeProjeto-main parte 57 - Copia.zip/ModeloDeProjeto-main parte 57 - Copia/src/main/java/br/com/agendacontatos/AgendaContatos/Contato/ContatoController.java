package br.com.agendacontatos.AgendaContatos.Contato;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class ContatoController extends Contatos {

    @Autowired
    private IContatoRepository ContatoRepository;

    @PostMapping("/create")
    public ResponseEntity create (@RequestBody ContatoModel ContatoModel){
       
        var Contato = this.ContatoRepository.findbyidUsuario(ContatoModel.getIdUsuario());
        
       
        if (Contato != null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Contato já existe");
        }

        
        var ContatoCreated = this.ContatoRepository.save(ContatoModel);

        
        return ResponseEntity.status(HttpStatus.CREATED).body(ContatoCreated);
    }
    
    @GetMapping("/list-reservas")
    
    public ResponseEntity<List<ContatoModel>> getAllcontatos() {
     
        List<ContatoModel> reservas = ContatoRepository.findAll();
        if (contatos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
        return ResponseEntity.ok(contatos);
    }


}
