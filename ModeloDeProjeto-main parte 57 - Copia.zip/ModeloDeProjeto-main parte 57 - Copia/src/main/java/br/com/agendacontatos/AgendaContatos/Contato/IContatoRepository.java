package br.com.agendacontatos.AgendaContatos.Contato;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IContatoRepository  extends JpaRepository <ContatoModel, UUID> {
    ContatoModel findbyidUsuario(String idUsuario);
    
}