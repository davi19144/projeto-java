package br.com.agendacontatos.AgendaContatos ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaContatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaContatosApplication.class, args);
	}
}
